package co.edu.icesi.internetcomputing.workshop.services;

public interface TsscSprintService {

}
