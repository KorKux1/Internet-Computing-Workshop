package co.edu.icesi.internetcomputing.workshop.repositories;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.internetcomputing.workshop.model.TsscGroup;

public interface TsscGroupRepository extends CrudRepository<TsscGroup, Long> {

}
