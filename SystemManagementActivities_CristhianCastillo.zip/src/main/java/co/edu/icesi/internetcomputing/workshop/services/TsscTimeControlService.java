package co.edu.icesi.internetcomputing.workshop.services;

public interface TsscTimeControlService {

}
