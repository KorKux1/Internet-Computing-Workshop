package co.edu.icesi.internetcomputing.workshop.repositories;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.internetcomputing.workshop.model.TsscSprint;

public interface TsscSprintRepository  extends CrudRepository<TsscSprint, Long>{

}
