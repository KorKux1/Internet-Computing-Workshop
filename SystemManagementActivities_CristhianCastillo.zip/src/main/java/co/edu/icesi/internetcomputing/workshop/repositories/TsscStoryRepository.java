package co.edu.icesi.internetcomputing.workshop.repositories;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.internetcomputing.workshop.model.TsscStory;

public interface TsscStoryRepository extends CrudRepository<TsscStory, Long>{
	
}
